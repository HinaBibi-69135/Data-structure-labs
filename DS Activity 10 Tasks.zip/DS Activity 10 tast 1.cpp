#include <iostream>
using namespace std;

#define SIZE 5

class Queue {
private:
    int arr[SIZE];
    int front, rear;

public:
    // Constructor
    Queue() {
        front = -1;
        rear = -1;
        for (int i = 0; i < SIZE; i++)
            arr[i] = -1;  // Initialize array with -1 for empty display
    }

    // Function to display queue status
    void display(string operation) {
        cout << "\nAfter " << operation << ":\n";

        if (front == -1 || front > rear) {
            cout << "Queue is Empty\n";
        } else {
            cout << "Front value: " << arr[front] << endl;
            cout << "Rear value: " << arr[rear] << endl;
        }

        cout << "Array: ";
        for (int i = 0; i < SIZE; i++) {
            if (arr[i] == -1)
                cout << "_ ";
            else
                cout << arr[i] << " ";
        }
        cout << endl;
    }

    // Enqueue operation
    void enQueue(int value) {
        if (rear == SIZE - 1) {
            cout << "\nCannot enqueue " << value << " -> Queue Overflow!\n";
            display("enQueue(" + to_string(value) + ")");
            return;
        }

        if (front == -1)
            front = 0;

        arr[++rear] = value;
        display("enQueue(" + to_string(value) + ")");
    }

    // Dequeue operation
    void deQueue() {
        if (front == -1 || front > rear) {
            cout << "\nCannot dequeue -> Queue Underflow!\n";
            display("deQueue()");
            return;
        }

        cout << "\nDequeued element: " << arr[front] << endl;
        arr[front] = -1;  // Mark as empty
        front++;

        // Reset queue when it becomes empty
        if (front > rear) {
            front = rear = -1;
        }

        display("deQueue()");
    }
};

int main() {
    Queue q;

    // Perform the given operations
    q.enQueue(10);
    q.enQueue(20);
    q.enQueue(30);
    q.deQueue();
    q.enQueue(40);
    q.enQueue(50);
    q.enQueue(60);  // This will cause overflow

    return 0;
}